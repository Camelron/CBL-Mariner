A completion file for zsh was added which can just be put into a directory of zsh's $fpath
(e.g. on gentoo into /usr/share/zsh/site-functions/)
